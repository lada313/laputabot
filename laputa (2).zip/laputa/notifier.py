import asyncio
import logging
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from analysis import analyze_stock

logger = logging.getLogger("notifier")

async def notify_price_changes(application, TICKERS, portfolio, last_signal, CHAT_ID,
                               get_moex_price_func, calculate_rsi_func):
    first_run = True
    last_price_signal = {}

    while True:
        for ticker, name in TICKERS.items():
            try:
                current_price = await get_moex_price_func(ticker)
                if current_price is None:
                    raise ValueError("Нет текущей цены")

                # === 🟩 Акции в портфеле ===
                if ticker in portfolio:
                    purchase_price = portfolio[ticker]["price"]
                    change = (current_price - purchase_price) / purchase_price * 100
                    signal_text = await analyze_stock(ticker)

                    # --- Анализ (Покупать / Продавать / Подождать) ---
                    if not first_run and signal_text != last_signal.get(ticker):
                        old = last_signal.get(ticker)
                        if old:
                            msg = (
                                f"🔄 *{name}* ({ticker}) — изменение сигнала\n\n"
                                f"💡 Было: {old}\n"
                                f"💡 Стало: {signal_text}"
                            )
                        else:
                            msg = (
                                f"📌 *{name}* ({ticker}) — новый сигнал:\n\n"
                                f"{signal_text}"
                            )

                        button = InlineKeyboardMarkup([
                            [InlineKeyboardButton("Открыть в Тинькофф", url=f"https://www.tinkoff.ru/invest/stocks/{ticker}")]
                        ])
                        await application.bot.send_message(chat_id=CHAT_ID, text=msg, parse_mode="Markdown", reply_markup=button)
                        last_signal[ticker] = signal_text

                    # --- Take Profit (+10%) ---
                    if change >= 10 and last_price_signal.get(ticker) != "take":
                        msg = (
                            f"💰 *{name}* ({ticker}) вырос на {change:.2f}% от цены покупки!\n"
                            f"🎯 Возможность зафиксировать прибыль (Take Profit)"
                        )
                        button = InlineKeyboardMarkup([
                            [InlineKeyboardButton("Открыть в Тинькофф", url=f"https://www.tinkoff.ru/invest/stocks/{ticker}")]
                        ])
                        await application.bot.send_message(chat_id=CHAT_ID, text=msg, parse_mode="Markdown", reply_markup=button)
                        last_price_signal[ticker] = "take"

                    # --- Stop Loss (−5%) ---
                    elif change <= -5 and last_price_signal.get(ticker) != "stop":
                        msg = (
                            f"⚠️ *{name}* ({ticker}) упал на {change:.2f}% от цены покупки!\n"
                            f"🔻 Подумай о защите капитала (Stop Loss)"
                        )
                        button = InlineKeyboardMarkup([
                            [InlineKeyboardButton("Открыть в Тинькофф", url=f"https://www.tinkoff.ru/invest/stocks/{ticker}")]
                        ])
                        await application.bot.send_message(chat_id=CHAT_ID, text=msg, parse_mode="Markdown", reply_markup=button)
                        last_price_signal[ticker] = "stop"

                    # --- Сброс сигнала, если цена вернулась в безопасную зону ---
                    elif -5 < change < 10:
                        last_price_signal[ticker] = None

                # === 👁️ Акции в отслежке ===
                else:
                    signal_text = await analyze_stock(ticker)
                    if not signal_text or "Покупать" not in signal_text:
                        continue  # Только если сигнал = Покупать

                    if not first_run and signal_text != last_signal.get(ticker):
                        msg = f"📌 *{name}* ({ticker})\n\n{signal_text}"
                        button = InlineKeyboardMarkup([
                            [InlineKeyboardButton("Открыть в Тинькофф", url=f"https://www.tinkoff.ru/invest/stocks/{ticker}")]
                        ])
                        await application.bot.send_message(chat_id=CHAT_ID, text=msg, parse_mode="Markdown", reply_markup=button)
                        last_signal[ticker] = signal_text

            except Exception as e:
                logger.error(f"Ошибка при уведомлении по {ticker}: {e}")

        first_run = False
        await asyncio.sleep(10 * 60)  # 10 минут
