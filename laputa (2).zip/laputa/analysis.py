import os
import asyncio
from datetime import datetime, timedelta
import numpy as np
from tinkoff.invest import (
    AsyncClient,
    CandleInterval,
)

TINKOFF_TOKEN = os.getenv("TINKOFF_TOKEN")

async def get_figi_by_ticker(ticker: str) -> str | None:
    async with AsyncClient(TINKOFF_TOKEN) as client:
        shares = await client.instruments.shares()
        for share in shares.instruments:
            if share.ticker.upper() == ticker.upper():
                return share.figi
    return None


def calculate_rsi(prices: list[float], period: int = 14) -> float | None:
    if len(prices) < period + 1:
        return None
    deltas = np.diff(prices)
    gains = np.where(deltas > 0, deltas, 0)
    losses = np.where(deltas < 0, -deltas, 0)

    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])

    for i in range(period, len(deltas)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))


def calculate_sma(prices: list[float], period: int) -> float | None:
    if len(prices) < period:
        return None
    return np.mean(prices[-period:])


def calculate_ema(prices: list[float], period: int) -> list[float]:
    ema = []
    k = 2 / (period + 1)
    for i in range(len(prices)):
        if i < period - 1:
            ema.append(None)
        elif i == period - 1:
            sma = np.mean(prices[:period])
            ema.append(sma)
        else:
            ema.append(prices[i] * k + ema[-1] * (1 - k))
    return ema


async def analyze_stock(ticker: str, detailed: bool = False) -> str:
    figi = await get_figi_by_ticker(ticker)
    if not figi:
        return f"❌ Не найден FIGI для {ticker}"

    async with AsyncClient(TINKOFF_TOKEN) as client:
        now_utc = datetime.utcnow()
        from_utc = now_utc - timedelta(days=300)

        candles = await client.market_data.get_candles(
            figi=figi,
            from_=from_utc,
            to=now_utc,
            interval=CandleInterval.CANDLE_INTERVAL_DAY
        )

        if not candles.candles:
            return f"❌ Нет данных по {ticker}"

        close_prices = [c.close.units + c.close.nano * 1e-9 for c in candles.candles]
        volumes = [c.volume for c in candles.candles]

        if len(close_prices) < 50:
            return f"❌ Недостаточно данных по {ticker}"

        weights = {
            "rsi": 2.0,
            "trend": 1.0,
            "volume": 0.5,
            "sma": 1.5,
            "macd": 1.0
        }

        details = []

        # RSI
        rsi_score = 0
        rsi_text = "не рассчитан"
        rsi = calculate_rsi(close_prices)
        if rsi is not None:
            if rsi < 30:
                rsi_score = 1
                rsi_text = f"{rsi:.1f} — перепродан ✅"
            elif rsi > 70:
                rsi_score = -1
                rsi_text = f"{rsi:.1f} — перекуплен ❌"
            else:
                rsi_text = f"{rsi:.1f} — нейтрально ➖"

        # Тренд
        trend_score = 0
        if close_prices[-1] > close_prices[-5]:
            trend_score = 1
            trend_text = "рост ✅"
        elif close_prices[-1] < close_prices[-5]:
            trend_score = -1
            trend_text = "падение ❌"
        else:
            trend_text = "боковой ➖"

        # Объём
        avg_volume = sum(volumes[:-1]) / (len(volumes) - 1)
        current_volume = volumes[-1]
        volume_score = 0
        if current_volume > avg_volume * 1.5:
            volume_score = 1
            volume_text = "высокий ✅"
        elif current_volume < avg_volume * 0.5:
            volume_score = -1
            volume_text = "низкий ❌"
        else:
            volume_text = "нормальный ➖"

        # SMA
        sma_score = 0
        sma_text = "недостаточно данных"
        sma50 = calculate_sma(close_prices, 50)
        sma200 = calculate_sma(close_prices, 200)
        if sma50 and sma200:
            if sma50 > sma200:
                sma_score = 1
                sma_text = "золотой крест ✅"
            else:
                sma_score = -1
                sma_text = "мёртвый крест ❌"

        # MACD
        macd_score = 0
        macd_text = "недоступен"
        ema12 = calculate_ema(close_prices, 12)
        ema26 = calculate_ema(close_prices, 26)
        macd_line = [e1 - e2 if e1 and e2 else None for e1, e2 in zip(ema12, ema26)]
        macd_signal = calculate_ema([m for m in macd_line if m is not None], 9)
        if macd_line[-1] and macd_signal[-1]:
            if macd_line[-1] > macd_signal[-1]:
                macd_score = 1
                macd_text = "импульс вверх ✅"
            else:
                macd_score = -1
                macd_text = "импульс вниз ❌"

        # Подсчёт итогового балла с весами
        weighted_score = (
            rsi_score * weights["rsi"] +
            trend_score * weights["trend"] +
            volume_score * weights["volume"] +
            sma_score * weights["sma"] +
            macd_score * weights["macd"]
        )

        if weighted_score >= 2.5:
            conclusion = "💡 Вывод: ✅ Покупать"
        elif weighted_score <= -2.5:
            conclusion = "💡 Вывод: 🔻 Продавать"
        else:
            conclusion = "💡 Вывод: ⏸ Подождать"

        # Советы по стоп-лоссу и тейк-профиту
        stop_loss_price = close_prices[-1] * 0.95  # -5% от текущей цены
        take_profit_price = close_prices[-1] * 1.10  # +10% от текущей цены
        stop_loss_text = f"🔻 *Стоп-лосс:* ~{stop_loss_price:.2f} ₽ (−5%)"
        take_profit_text = f"💰 *Тейк-профит:* ~{take_profit_price:.2f} ₽ (+10%)"

        if detailed:
            return (
                f"📊 Подробный анализ {ticker}:\n\n"
                f"• RSI: {rsi_text}\n"
                f"• Тренд: {trend_text}\n"
                f"• Объём: {volume_text}\n"
                f"• SMA-50/200: {sma_text}\n"
                f"• MACD: {macd_text}\n"
                f"\n🎯 Весовая оценка: {weighted_score:.1f}\n"
                f"{conclusion}\n\n"
                f"{stop_loss_text}\n"
                f"{take_profit_text}"
            )
        else:
            return (
                f"{conclusion}\n"
            )


async def main():
    print(await analyze_stock("SBER", detailed=True))


if __name__ == "__main__":
    asyncio.run(main())
